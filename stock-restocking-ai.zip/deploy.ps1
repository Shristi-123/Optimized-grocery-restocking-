# PowerShell Deployment Script for AuraStock AI on Vercel
# Uses a portable Node.js setup to avoid requiring global system installations.

$ErrorActionPreference = "Stop"

# Define Paths
$WorkspacePath = "C:\Users\HP\.gemini\antigravity\scratch"
$ProjectName = "stock-restocking-ai"
$ProjectPath = Join-Path $WorkspacePath $ProjectName
$NodeZipUrl = "https://nodejs.org/dist/v20.15.1/node-v20.15.1-win-x64.zip"
$NodeEnvDir = Join-Path $WorkspacePath "node-env"
$NodeZipPath = Join-Path $WorkspacePath "node.zip"

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "   AuraStock AI Vercel Deployment Assistant  " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# 1. Setup Portable Node.js
if (!(Test-Path $NodeEnvDir)) {
    Write-Host "Creating portable Node.js environment directory..." -ForegroundColor Green
    New-Item -ItemType Directory -Path $NodeEnvDir | Out-Null
}

$NodeSubdir = Join-Path $NodeEnvDir "node-v20.15.1-win-x64"
$NodeExe = Join-Path $NodeSubdir "node.exe"

if (!(Test-Path $NodeExe)) {
    Write-Host "Portable Node.js not found. Downloading..." -ForegroundColor Yellow
    Write-Host "Downloading $NodeZipUrl..." -ForegroundColor Gray
    
    # Download zip
    Invoke-WebRequest -Uri $NodeZipUrl -OutFile $NodeZipPath
    
    Write-Host "Extracting archive to $NodeEnvDir..." -ForegroundColor Yellow
    Expand-Archive -Path $NodeZipPath -DestinationPath $NodeEnvDir -Force
    
    # Cleanup zip
    Remove-Item $NodeZipPath -Force
    Write-Host "Node.js successfully installed locally." -ForegroundColor Green
} else {
    Write-Host "Portable Node.js detected in workspace." -ForegroundColor Green
}

# Add local Node to path for this session
Write-Host "Configuring session environment variables..." -ForegroundColor Yellow
$env:Path = "$NodeSubdir;" + $env:Path

# Test Node connection
$nodeVer = & node -v
$npmVer = & npm -v
Write-Host "Using Node.js version: $nodeVer" -ForegroundColor Gray
Write-Host "Using NPM version: $npmVer" -ForegroundColor Gray

# 2. Setup Vercel CLI in Project
Set-Location $ProjectPath
Write-Host "Project directory: $ProjectPath" -ForegroundColor Gray

if (!(Test-Path (Join-Path $ProjectPath "node_modules\vercel"))) {
    Write-Host "Vercel CLI package not found in project. Installing..." -ForegroundColor Yellow
    # Install vercel package locally
    & npm install vercel --no-audit --no-fund
    Write-Host "Vercel CLI installed successfully." -ForegroundColor Green
} else {
    Write-Host "Vercel CLI package detected in project." -ForegroundColor Green
}

# 3. Trigger Vercel Deployment
Write-Host ""
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " Launching Vercel deployment command..." -ForegroundColor Cyan
Write-Host " NOTE: If this is your first time, Vercel will open a" -ForegroundColor Yellow
Write-Host " browser window asking you to authenticate/log in." -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

# Run Vercel deployment
& npx vercel --prod --yes
