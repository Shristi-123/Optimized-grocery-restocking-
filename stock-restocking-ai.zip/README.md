# AuraStock AI - Optimized Stock Restocking Dashboard

AuraStock AI is an optimized stock restocking intelligence tool designed to manage inventory levels, forecast consumer demand, and automate restocking quantities with Indian Rupee (₹) pricing.

## 🚀 Live Preview
Try it live on Vercel: [https://stock-restocking-ai.vercel.app](https://stock-restocking-ai.vercel.app)

## 🛠️ Features
- **Economic Order Quantity (EOQ)**: Calculates cost-minimizing order sizes based on annual carrying costs and ordering fees.
- **Reorder Point (ROP)**: Dynamic triggers that flag items for reordering when stock drops below lead time demand and safety buffers.
- **Sales Simulation**: Daily/Weekly simulator modeled with statistical noise and seasonality.
- **Advanced Gemini AI Integration**: (Optional) Connect your Google Gemini API key to receive intelligent narrative restocking rationales.
- **Modern UI**: Clean, glassmorphic dark theme dashboard built with Chart.js and Lucide Icons.

## 📂 Project Structure
- `index.html`: Dashboard page layout.
- `style.css`: Glassmorphic styling system.
- `app.js`: Logic, formulas, and local database management.
- `deploy.ps1`: Automated portable Node.js Vercel deployment script for Windows.
- `vercel.json`: Deployment routes config.

## 💻 Local Setup
1. Clone the repository or extract the ZIP file.
2. Open `index.html` in any web browser to run locally.
3. (Optional) Run `./deploy.ps1` in PowerShell on Windows to redeploy the site to your Vercel account.
