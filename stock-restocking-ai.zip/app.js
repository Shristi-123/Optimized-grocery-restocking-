// AuraStock AI - Application Engine

// Global State
let state = {
    products: [],
    orders: [],
    notifications: [],
    settings: {
        orderCost: 500, // S
        holdingRate: 0.20, // H (20% of cost)
        geminiKey: '',
        geminiModel: 'gemini-1.5-flash',
        volatility: 0.15,
        seasonality: 0.25
    },
    currentTab: 'dashboard',
    simulatedDays: 0,
    selectedProductForInsight: null
};

// Default Catalog Data
const DEFAULT_PRODUCTS = [
    {
        id: 'prod-1',
        sku: 'CLO-SILK-01',
        name: 'Silk Thread Banarasi Saree',
        category: 'Clothing',
        stock: 14,
        price: 4500,
        cost: 2200,
        leadTime: 7,
        safetyStock: 8,
        annualDemand: 450,
        dailyVelocity: 1.25 // Calculated: annualDemand / 365
    },
    {
        id: 'prod-2',
        sku: 'ELE-EARB-02',
        name: 'Aura Wireless Earbuds X2',
        category: 'Electronics',
        stock: 82,
        price: 2499,
        cost: 1100,
        leadTime: 3,
        safetyStock: 15,
        annualDemand: 2200,
        dailyVelocity: 6.03
    },
    {
        id: 'prod-3',
        sku: 'GRO-RICE-03',
        name: 'Premium Basmati Rice 5kg',
        category: 'Grocery',
        stock: 120,
        price: 650,
        cost: 450,
        leadTime: 4,
        safetyStock: 25,
        annualDemand: 4800,
        dailyVelocity: 13.15
    },
    {
        id: 'prod-4',
        sku: 'BEA-SERU-04',
        name: 'Organic Retinol Face Serum',
        category: 'Beauty',
        stock: 5,
        price: 1200,
        cost: 500,
        leadTime: 6,
        safetyStock: 12,
        annualDemand: 950,
        dailyVelocity: 2.60
    },
    {
        id: 'prod-5',
        sku: 'AUT-HEAD-05',
        name: 'LED Headlamp Bulbs H7',
        category: 'Automotive',
        stock: 45,
        price: 1800,
        cost: 950,
        leadTime: 5,
        safetyStock: 10,
        annualDemand: 800,
        dailyVelocity: 2.19
    },
    {
        id: 'prod-6',
        sku: 'GRO-TURM-06',
        name: 'Organic Turmeric Powder 250g',
        category: 'Grocery',
        stock: 0,
        price: 180,
        cost: 90,
        leadTime: 3,
        safetyStock: 20,
        annualDemand: 3000,
        dailyVelocity: 8.22
    },
    {
        id: 'prod-7',
        sku: 'ELE-SMAR-07',
        name: 'FitTrack Pro Smartwatch',
        category: 'Electronics',
        stock: 28,
        price: 5999,
        cost: 2900,
        leadTime: 5,
        safetyStock: 10,
        annualDemand: 1100,
        dailyVelocity: 3.01
    }
];

const DEFAULT_ORDERS = [
    {
        id: 'ord-9821',
        dateCreated: '2026-07-10',
        items: [
            { name: 'Organic Retinol Face Serum', qty: 62, cost: 500 }
        ],
        totalCost: 31000,
        expectedDelivery: '2026-07-16',
        status: 'In Transit'
    },
    {
        id: 'ord-8172',
        dateCreated: '2026-07-05',
        items: [
            { name: 'Organic Turmeric Powder 250g', qty: 250, cost: 90 },
            { name: 'Premium Basmati Rice 5kg', qty: 150, cost: 450 }
        ],
        totalCost: 90000,
        expectedDelivery: '2026-07-09',
        status: 'Delivered'
    }
];

// Sound generator using Web Audio API
function playBeep(type) {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        if (type === 'alert') {
            oscillator.type = 'triangle';
            oscillator.frequency.setValueAtTime(440, audioCtx.currentTime); // A4
            oscillator.frequency.setValueAtTime(660, audioCtx.currentTime + 0.15); // E5
            gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
            oscillator.start();
            oscillator.stop(audioCtx.currentTime + 0.3);
        } else if (type === 'success') {
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
            oscillator.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1); // E5
            oscillator.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.2); // G5
            gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
            oscillator.start();
            oscillator.stop(audioCtx.currentTime + 0.35);
        }
    } catch (e) {
        console.warn('Web Audio not supported or blocked by browser policy');
    }
}

// Local Storage Sync
function loadState() {
    const savedProducts = localStorage.getItem('aurastock_products');
    const savedOrders = localStorage.getItem('aurastock_orders');
    const savedSettings = localStorage.getItem('aurastock_settings');
    const savedNotifications = localStorage.getItem('aurastock_notifications');
    const savedSimDays = localStorage.getItem('aurastock_sim_days');

    if (savedProducts) state.products = JSON.parse(savedProducts);
    else state.products = [...DEFAULT_PRODUCTS];

    if (savedOrders) state.orders = JSON.parse(savedOrders);
    else state.orders = [...DEFAULT_ORDERS];

    if (savedSettings) state.settings = JSON.parse(savedSettings);
    if (savedNotifications) state.notifications = JSON.parse(savedNotifications);
    if (savedSimDays) state.simulatedDays = parseInt(savedSimDays) || 0;

    // Synchronize Form Values in Settings
    document.getElementById('setting-order-cost').value = state.settings.orderCost;
    document.getElementById('setting-holding-cost-rate').value = Math.round(state.settings.holdingRate * 100);
    document.getElementById('setting-gemini-key').value = state.settings.geminiKey || '';
    document.getElementById('setting-model-select').value = state.settings.geminiModel || 'gemini-1.5-flash';
    document.getElementById('setting-demand-volatility').value = Math.round(state.settings.volatility * 100);
    document.getElementById('range-volatility-val').textContent = `${Math.round(state.settings.volatility * 100)}%`;
    document.getElementById('setting-seasonality').value = Math.round(state.settings.seasonality * 100);
    document.getElementById('range-seasonality-val').textContent = `${Math.round(state.settings.seasonality * 100)}%`;
}

function saveState() {
    localStorage.setItem('aurastock_products', JSON.stringify(state.products));
    localStorage.setItem('aurastock_orders', JSON.stringify(state.orders));
    localStorage.setItem('aurastock_settings', JSON.stringify(state.settings));
    localStorage.setItem('aurastock_notifications', JSON.stringify(state.notifications));
    localStorage.setItem('aurastock_sim_days', state.simulatedDays.toString());
}

// Math Models
function calculateROP(product) {
    // ROP = (Daily Sales Velocity * Lead Time) + Safety Stock
    return Math.ceil((product.dailyVelocity * product.leadTime) + product.safetyStock);
}

function calculateEOQ(product) {
    // EOQ = sqrt((2 * AnnualDemand * OrderingCost) / HoldingCostPerUnit)
    const D = product.annualDemand;
    const S = state.settings.orderCost;
    const H = product.cost * state.settings.holdingRate;
    if (H === 0) return 100;
    return Math.ceil(Math.sqrt((2 * D * S) / H));
}

function getProductStatus(product) {
    const rop = calculateROP(product);
    if (product.stock === 0) return { label: 'Out of Stock', class: 'status-out', progressClass: 'out' };
    if (product.stock <= rop) return { label: 'Low Stock', class: 'status-low', progressClass: 'low' };
    return { label: 'Healthy', class: 'status-healthy', progressClass: 'healthy' };
}

// Get seasonal multipliers based on current simulation day
function getSeasonalMultiplier(dayOffset = 0) {
    const currentDay = state.simulatedDays + dayOffset;
    // 365 day cycle, standard seasonality multiplier (e.g. peak at days 180 and 360)
    const angle = (currentDay / 365) * 2 * Math.PI;
    const seasonalityEffect = state.settings.seasonality * Math.sin(angle);
    return 1 + seasonalityEffect;
}

// Simulation functions
function simulateSales(days = 1) {
    let triggeredAlerts = false;
    
    for (let d = 0; d < days; d++) {
        state.simulatedDays++;
        const multiplier = getSeasonalMultiplier();
        
        state.products.forEach(p => {
            if (p.stock <= 0) {
                p.stock = 0;
                return;
            }
            
            // Expected sales = velocity * seasonal multiplier
            const expectedSales = p.dailyVelocity * multiplier;
            // Introduce noise
            const randomNoise = (Math.random() * 2 - 1) * state.settings.volatility * expectedSales;
            const actualSales = Math.max(0, Math.round(expectedSales + randomNoise));
            
            const prevStock = p.stock;
            p.stock = Math.max(0, p.stock - actualSales);
            
            // Check status change to trigger notifications
            const rop = calculateROP(p);
            if (p.stock <= rop && prevStock > rop) {
                addNotification(`Low Stock Alert: ${p.name} is down to ${p.stock} units. ROP is ${rop}.`, 'warning');
                triggeredAlerts = true;
            } else if (p.stock === 0 && prevStock > 0) {
                addNotification(`Out of Stock Alert: ${p.name} has run out of stock.`, 'danger');
                triggeredAlerts = true;
            }
        });

        // Advance transit orders by 1 day
        state.orders.forEach(o => {
            if (o.status === 'In Transit') {
                // simple date check or simulation logic. Let's say it reduces delivery time.
                // For simplicity, we just mark it as Delivered automatically after lead time.
                // Let's check date simulation.
                const orderDate = new Date(o.dateCreated);
                const deliveryDate = new Date(o.expectedDelivery);
                const currentSimulatedTime = new Date('2026-07-14');
                currentSimulatedTime.setDate(currentSimulatedTime.getDate() + state.simulatedDays);
                
                if (currentSimulatedTime >= deliveryDate) {
                    o.status = 'Delivered';
                    // Restock products
                    o.items.forEach(item => {
                        const prod = state.products.find(p => p.name === item.name);
                        if (prod) {
                            prod.stock += item.qty;
                            addNotification(`Order Complete: Received ${item.qty} units of ${prod.name}.`, 'success');
                            triggeredAlerts = true;
                        }
                    });
                }
            }
        });
    }

    if (triggeredAlerts) {
        playBeep('alert');
    }
    
    saveState();
    renderAll();
}

// Notifications
function addNotification(message, type = 'info') {
    const notif = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        message,
        type,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: false
    };
    state.notifications.unshift(notif);
    // Keep max 20
    if (state.notifications.length > 20) state.notifications.pop();
    saveState();
}

// Formatting Helper
function formatRupees(num) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(num);
}

// Render Dashboard Tab
function renderDashboard() {
    // Total SKUs
    document.getElementById('kpi-total-skus').textContent = state.products.length;
    
    // Critical Low Stock Count
    const lowStockCount = state.products.filter(p => p.stock <= calculateROP(p)).length;
    document.getElementById('kpi-low-stock').textContent = lowStockCount;
    const lowStockSubText = document.getElementById('kpi-low-stock-sub');
    if (lowStockCount > 0) {
        lowStockSubText.innerHTML = `<span class="text-danger">${lowStockCount} items need attention</span>`;
        document.getElementById('dashboard-alert-banner').style.display = 'flex';
        document.getElementById('alert-banner-msg').textContent = `${lowStockCount} item(s) are currently below safety stock limits.`;
    } else {
        lowStockSubText.innerHTML = `<span style="color: var(--success)">All stock levels healthy</span>`;
        document.getElementById('dashboard-alert-banner').style.display = 'none';
    }

    // Total Inventory Value
    const totalVal = state.products.reduce((acc, p) => acc + (p.stock * p.cost), 0);
    document.getElementById('kpi-total-value').textContent = formatRupees(totalVal);

    // AI Savings Simulation (mocked comparison against traditional reordering)
    const annualHoldingCost = state.products.reduce((acc, p) => acc + (calculateEOQ(p) * p.cost * state.settings.holdingRate / 2), 0);
    const fixedOrderFreqSavings = state.products.length * 3500; // estimated savings
    document.getElementById('kpi-savings').textContent = formatRupees(fixedOrderFreqSavings);

    // Load recommendations preview
    const recsTable = document.getElementById('dashboard-recommendations-table');
    recsTable.innerHTML = '';
    
    const lowStockItems = state.products
        .map(p => ({
            product: p,
            rop: calculateROP(p),
            eoq: calculateEOQ(p),
            status: getProductStatus(p)
        }))
        .filter(item => item.product.stock <= item.rop)
        .sort((a, b) => (a.product.stock / a.rop) - (b.product.stock / b.rop)); // most critical first

    if (lowStockItems.length === 0) {
        recsTable.innerHTML = `<tr><td colspan="8" class="placeholder-text" style="padding: 30px; text-align: center;">No urgent restock recommendations. All stock is healthy!</td></tr>`;
    } else {
        lowStockItems.slice(0, 5).forEach(item => {
            const p = item.product;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${p.name}</strong><br><span style="font-size:0.75rem; color:var(--text-muted)">${p.sku}</span></td>
                <td>${p.category}</td>
                <td><span class="status-pill ${item.status.class}">${item.status.label}</span></td>
                <td>${p.stock}</td>
                <td>${item.rop}</td>
                <td><span style="color: var(--accent); font-weight:600;">+${item.eoq} units</span></td>
                <td>${formatRupees(item.eoq * p.cost)}</td>
                <td><button class="btn btn-primary btn-sm" onclick="quickRestock('${p.id}')">Restock</button></td>
            `;
            recsTable.appendChild(row);
        });
    }
}

// Quick restock action
function quickRestock(prodId) {
    const prod = state.products.find(p => p.id === prodId);
    if (!prod) return;
    
    // Add to AI Optimizer selected order
    switchTab('optimizer');
    // Highlight the row or just select it
    setTimeout(() => {
        const checkbox = document.querySelector(`.opt-select[data-id="${prodId}"]`);
        if (checkbox) {
            checkbox.checked = true;
            updateSelectedRestockCount();
            selectProductForInsight(prodId);
        }
    }, 100);
}

// Render Inventory Tab
let inventoryPage = 1;
const itemsPerPage = 8;

function renderInventory() {
    const catFilter = document.getElementById('inventory-filter-category').value;
    const statusFilter = document.getElementById('inventory-filter-status').value;
    const searchVal = document.getElementById('global-search').value.toLowerCase();

    let filtered = state.products.filter(p => {
        const matchesCategory = catFilter === 'All' || p.category === catFilter;
        const matchesSearch = p.name.toLowerCase().includes(searchVal) || p.sku.toLowerCase().includes(searchVal);
        
        const status = getProductStatus(p).label;
        const matchesStatus = statusFilter === 'All' || status === statusFilter;

        return matchesCategory && matchesSearch && matchesStatus;
    });

    const tbody = document.getElementById('inventory-table-body');
    tbody.innerHTML = '';

    // Pagination
    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (inventoryPage > totalPages) inventoryPage = totalPages;

    const startIndex = (inventoryPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
    const paginated = filtered.slice(startIndex, endIndex);

    if (paginated.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="placeholder-text">No products found matching filters.</td></tr>`;
    } else {
        paginated.forEach(p => {
            const rop = calculateROP(p);
            const status = getProductStatus(p);
            const ratio = Math.min(100, Math.round((p.stock / (rop * 1.5)) * 100));
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><span style="font-family:monospace; font-weight:600">${p.sku}</span></td>
                <td><strong>${p.name}</strong></td>
                <td>${p.category}</td>
                <td>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span>${p.stock}</span>
                        <span style="font-size:0.75rem; color:var(--text-muted)">/ ROP ${rop}</span>
                    </div>
                    <div class="stock-progress-bar">
                        <div class="stock-progress-fill ${status.progressClass}" style="width: ${ratio}%"></div>
                    </div>
                </td>
                <td>${formatRupees(p.price)}</td>
                <td>${formatRupees(p.cost)}</td>
                <td>${p.leadTime} days</td>
                <td>${p.safetyStock} units</td>
                <td>
                    <div style="display:flex; gap:6px;">
                        <button class="btn btn-icon btn-outline btn-sm" onclick="editProduct('${p.id}')"><i data-lucide="edit-3" style="width:14px;height:14px"></i></button>
                        <button class="btn btn-icon btn-outline btn-sm" onclick="deleteProduct('${p.id}')" style="color:var(--danger)"><i data-lucide="trash-2" style="width:14px;height:14px"></i></button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    // Update Lucide Icons in table
    lucide.createIcons();

    // Update Pagination UI
    document.getElementById('inventory-pagination-info').textContent = `Showing ${totalItems > 0 ? startIndex + 1 : 0}-${endIndex} of ${totalItems} products`;
    const pagButtons = document.querySelectorAll('.pagination-buttons button');
    pagButtons[0].disabled = inventoryPage === 1;
    pagButtons[1].disabled = inventoryPage === totalPages;
    
    pagButtons[0].onclick = () => { if (inventoryPage > 1) { inventoryPage--; renderInventory(); } };
    pagButtons[1].onclick = () => { if (inventoryPage < totalPages) { inventoryPage++; renderInventory(); } };
}

// Render AI Optimizer Tab
function renderOptimizer() {
    const tbody = document.getElementById('optimizer-recommendations-table');
    tbody.innerHTML = '';

    state.products.forEach(p => {
        const rop = calculateROP(p);
        const eoq = calculateEOQ(p);
        const isCritical = p.stock <= rop;
        const estCost = eoq * p.cost;
        const leadTimeDemand = Math.round(p.dailyVelocity * p.leadTime);
        
        // AI Confidence score is higher for low volatility products
        const confidence = Math.round(100 - (state.settings.volatility * 100) - (Math.random() * 5));

        const row = document.createElement('tr');
        row.style.cursor = 'pointer';
        row.onclick = (e) => {
            if (e.target.tagName !== 'INPUT') {
                selectProductForInsight(p.id);
            }
        };

        if (state.selectedProductForInsight === p.id) {
            row.style.backgroundColor = 'rgba(56, 189, 248, 0.05)';
            row.style.borderLeft = '3px solid var(--accent)';
        }

        row.innerHTML = `
            <td><input type="checkbox" class="opt-select" data-id="${p.id}" ${isCritical ? 'checked' : ''} onchange="updateSelectedRestockCount()"></td>
            <td><strong>${p.name}</strong><br><span style="font-size:0.75rem; color:var(--text-muted)">SKU: ${p.sku}</span></td>
            <td>
                <div style="font-weight:600; color: ${isCritical ? 'var(--danger)' : 'var(--success)'}">${p.stock} units</div>
                <div style="font-size:0.75rem; color:var(--text-muted)">Min (ROP): ${rop}</div>
            </td>
            <td>${leadTimeDemand} units</td>
            <td><span style="font-weight:600; color:var(--accent)">+${eoq} units</span></td>
            <td><strong>${formatRupees(estCost)}</strong></td>
            <td>
                <div style="display:flex; align-items:center; gap:6px;">
                    <span style="color:var(--success); font-weight:600;">${confidence}%</span>
                    <span style="font-size:0.75rem; color:var(--text-muted)">High</span>
                </div>
            </td>
            <td>
                <span class="status-pill ${isCritical ? (p.stock === 0 ? 'status-out' : 'status-low') : 'status-healthy'}">
                    ${isCritical ? (p.stock === 0 ? 'CRITICAL' : 'HIGH') : 'ADEQUATE'}
                </span>
            </td>
        `;
        tbody.appendChild(row);
    });

    updateSelectedRestockCount();
    renderAIInsight();
}

function updateSelectedRestockCount() {
    const selected = document.querySelectorAll('.opt-select:checked').length;
    const btn = document.getElementById('btn-approve-selected');
    if (selected > 0) {
        btn.innerHTML = `<i data-lucide="check-circle-2"></i> Approve ${selected} orders & Create PO`;
        btn.disabled = false;
        btn.style.opacity = '1';
    } else {
        btn.innerHTML = `<i data-lucide="check-circle-2"></i> Select items to restock`;
        btn.disabled = true;
        btn.style.opacity = '0.5';
    }
    lucide.createIcons();
}

function selectProductForInsight(id) {
    state.selectedProductForInsight = id;
    renderOptimizer();
}

// Generate narrative insights using simple analytics or Gemini API
async function renderAIInsight() {
    const container = document.getElementById('ai-reasoning-container');
    const pId = state.selectedProductForInsight || (state.products.length > 0 ? state.products[0].id : null);
    
    if (!pId) {
        container.innerHTML = `<p class="placeholder-text">Add a product to get AI insights.</p>`;
        return;
    }

    const p = state.products.find(item => item.id === pId);
    if (!p) return;

    container.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:center; padding:30px;">
            <div style="border: 3px solid rgba(255,255,255,0.1); border-top: 3px solid var(--accent); border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite;"></div>
        </div>
    `;

    const rop = calculateROP(p);
    const eoq = calculateEOQ(p);
    const holdingCost = p.cost * state.settings.holdingRate;
    const dailyDemand = p.dailyVelocity;
    const seasonalFactor = getSeasonalMultiplier().toFixed(2);
    const leadTimeDemand = Math.round(dailyDemand * p.leadTime);
    const predictedWeeklyDemand = Math.round(dailyDemand * 7 * getSeasonalMultiplier(3));

    // Dynamic prompt details for Gemini
    const systemPrompt = `You are a Supply Chain Optimization AI Engine inside AuraStock AI. Explain the restocking recommendations for the product based on inventory parameters. Keep the response concise, formatted in markdown, with clear sections. Mention pricing in Rupees (₹) and use the exact calculated math details provided.`;
    const userPrompt = `
    Analyze restocking parameters for product: "${p.name}" (SKU: ${p.sku}, Category: ${p.category})
    - Current Stock: ${p.stock} units
    - Safety Stock: ${p.safetyStock} units
    - Supplier Lead Time: ${p.leadTime} days
    - Reorder Point (ROP): ${rop} units (calculated as: (${dailyDemand.toFixed(2)} daily sales * ${p.leadTime} days lead time) + ${p.safetyStock} safety stock)
    - Economic Order Quantity (EOQ): ${eoq} units (formula: sqrt(2 * ${p.annualDemand} annual demand * ₹${state.settings.orderCost} order cost / ₹${holdingCost.toFixed(2)} holding cost))
    - Active Seasonal Multiplier: ${seasonalFactor}x
    - Estimated Restock Purchase Cost: ₹${(eoq * p.cost).toLocaleString('en-IN')} (Quantity ${eoq} * unit cost ₹${p.cost})
    
    Provide:
    1. **Decision Analysis**: State clearly whether to restock now or wait. Explain how current stock (${p.stock}) compares to Reorder Point (${rop}).
    2. **Supply Chain Calculations**: Show the formula results and what they mean.
    3. **AI Recommendations**: A short narrative on demand trends, expected seasonal fluctuations, and the financial benefit of ordering the EOQ amount instead of ad-hoc numbers.
    `;

    // Check if Gemini Key is available
    if (state.settings.geminiKey) {
        try {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${state.settings.geminiModel}:generateContent?key=${state.settings.geminiKey}`;
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [
                        { role: 'user', parts: [{ text: `${systemPrompt}\n\n${userPrompt}` }] }
                    ]
                })
            });
            const data = await response.json();
            if (data.candidates && data.candidates[0].content.parts[0].text) {
                let markdown = data.candidates[0].content.parts[0].text;
                // Parse markdown into HTML (simplistic parser for standard format)
                container.innerHTML = parseMarkdown(markdown);
                return;
            }
        } catch (err) {
            console.error('Gemini API Error:', err);
            addNotification('Gemini API connection failed. Falling back to local forecasting.', 'warning');
        }
    }

    // Heuristics Fallback (Local Intelligent Reasoning)
    setTimeout(() => {
        const isBelowROP = p.stock <= rop;
        const urgency = p.stock === 0 ? 'CRITICAL (OUT OF STOCK)' : (p.stock <= p.safetyStock ? 'URGENT (BELOW SAFETY LIMIT)' : (isBelowROP ? 'WARNING (REACHED REORDER POINT)' : 'HEALTHY'));
        
        let localNarrative = `
            <h4 style="color:var(--accent); margin-bottom:8px;">AI Forecast: ${p.name}</h4>
            <p><strong>Status:</strong> <span class="status-pill ${isBelowROP ? (p.stock === 0 ? 'status-out' : 'status-low') : 'status-healthy'}">${urgency}</span></p>
            <p style="margin-top:12px;"><strong>AI Core Analysis:</strong></p>
            <p>Current stock is <strong>${p.stock} units</strong>. The reorder point is <strong>${rop} units</strong> (includes safety stock buffer of ${p.safetyStock} units). Since current stock is ${isBelowROP ? 'below' : 'above'} the reorder point, the system ${isBelowROP ? 'recommends placing an order immediately' : 'suggests monitoring stock levels'}.</p>
            
            <div class="insight-metric">
                <div class="insight-metric-row">
                    <span class="insight-metric-label">Estimated Lead Time Demand</span>
                    <span class="insight-metric-value">${leadTimeDemand} units</span>
                </div>
                <div class="insight-metric-row">
                    <span class="insight-metric-label">Seasonality Impact</span>
                    <span class="insight-metric-value">${(seasonalFactor * 100 - 100).toFixed(0)}% (${seasonalFactor}x demand)</span>
                </div>
                <div class="insight-metric-row">
                    <span class="insight-metric-label">AI Calculated Order Qty</span>
                    <span class="insight-metric-value">${eoq} units</span>
                </div>
                <div class="insight-metric-row">
                    <span class="insight-metric-label">Total Cost Projection</span>
                    <span class="insight-metric-value">${formatRupees(eoq * p.cost)}</span>
                </div>
            </div>
            
            <p style="margin-top:12px;"><strong>Mathematical Optimization Benefit:</strong></p>
            <p>Ordering the Economic Order Quantity (<strong>${eoq} units</strong>) balances carrying cost (₹${holdingCost.toFixed(0)}/unit/year) with transactional ordering cost (₹${state.settings.orderCost}). Adhering to this limit prevents capital lockup and saves approximately <strong>18% in warehouse holding fees</strong> compared to bulk buying.</p>
        `;
        container.innerHTML = localNarrative;
    }, 400);
}

// Simple MD Parser
function parseMarkdown(md) {
    let html = md;
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    html = html.replace(/### (.*?)\n/g, '<h4 style="color:var(--accent); margin-top:16px; margin-bottom:8px;">$1</h4>');
    html = html.replace(/## (.*?)\n/g, '<h3 style="color:var(--text-primary); margin-top:20px; border-bottom:1px solid var(--border-color); padding-bottom:4px;">$1</h3>');
    html = html.replace(/- (.*?)\n/g, '<li style="margin-left:16px; margin-bottom:4px;">$1</li>');
    html = html.replace(/\n\n/g, '<p style="margin-bottom:10px;"></p>');
    return html;
}

// Render Restock Orders Tab
function renderOrders() {
    const tbody = document.getElementById('orders-table-body');
    tbody.innerHTML = '';

    if (state.orders.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="placeholder-text">No restocking orders placed yet.</td></tr>`;
        return;
    }

    state.orders.forEach(o => {
        const itemsList = o.items.map(i => `${i.name} (x${i.qty})`).join(', ');
        
        let statusClass = 'status-low';
        if (o.status === 'Delivered') statusClass = 'status-healthy';
        if (o.status === 'Cancelled') statusClass = 'status-out';

        const row = document.createElement('tr');
        row.innerHTML = `
            <td><span style="font-family:monospace; font-weight:600">${o.id}</span></td>
            <td>${o.dateCreated}</td>
            <td>${itemsList}</td>
            <td><strong>${formatRupees(o.totalCost)}</strong></td>
            <td>${o.expectedDelivery}</td>
            <td><span class="status-pill ${statusClass}">${o.status}</span></td>
            <td>
                ${o.status === 'In Transit' ? `<button class="btn btn-outline btn-sm" onclick="markOrderDelivered('${o.id}')">Receive Delivery</button>` : `<span style="color:var(--text-muted);font-size:0.8rem">No action</span>`}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function markOrderDelivered(orderId) {
    const order = state.orders.find(o => o.id === orderId);
    if (!order) return;
    
    order.status = 'Delivered';
    order.items.forEach(item => {
        const prod = state.products.find(p => p.name === item.name);
        if (prod) {
            prod.stock += item.qty;
            addNotification(`Stock Updated: Received ${item.qty} units of ${prod.name}.`, 'success');
        }
    });

    playBeep('success');
    saveState();
    renderAll();
}

// Setup forecasting chart using Chart.js
let forecastChartInstance = null;
let healthDoughnutChartInstance = null;

function setupCharts() {
    const ctxForecast = document.getElementById('forecastChart');
    if (!ctxForecast) return;

    const pSelector = document.getElementById('forecast-product-selector');
    const selectedProdId = pSelector.value || (state.products.length > 0 ? state.products[0].id : null);
    const product = state.products.find(p => p.id === selectedProdId);

    if (!product) return;

    // Generate historical sales (15 days) and forecast sales (30 days)
    const historyDays = 15;
    const forecastDays = 30;
    
    const labels = [];
    const actualData = [];
    const forecastData = [];
    const ropData = [];
    const safetyStockData = [];
    const projectedStockData = []; // what happens if we do not order
    const restockedStockData = [];  // what happens if we order EOQ

    const rop = calculateROP(product);
    const eoq = calculateEOQ(product);

    // Sales Velocity
    const velocity = product.dailyVelocity;

    // 1. Generate History
    let runningStock = product.stock + (velocity * historyDays); // estimate stock 15 days ago
    for (let i = historyDays; i > 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString([], { month: 'short', day: 'numeric' }));
        
        // Sim historical sales
        const mult = getSeasonalMultiplier(-i);
        const expectedSales = velocity * mult;
        const sales = Math.max(0, Math.round(expectedSales + (Math.random() * 2 - 1) * state.settings.volatility * expectedSales));
        
        actualData.push(sales);
        forecastData.push(null);
        ropData.push(rop);
        safetyStockData.push(product.safetyStock);
        
        runningStock = Math.max(0, runningStock - sales);
    }

    // Today
    labels.push('Today');
    actualData.push(null);
    forecastData.push(Math.round(velocity * getSeasonalMultiplier(0)));
    ropData.push(rop);
    safetyStockData.push(product.safetyStock);
    
    let noOrderStock = product.stock;
    let orderStock = product.stock;
    let orderPlaced = false;
    let orderDeliveryDay = product.leadTime;

    projectedStockData.push(noOrderStock);
    restockedStockData.push(orderStock);

    // 2. Generate Forecast
    for (let i = 1; i <= forecastDays; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        labels.push(date.toLocaleDateString([], { month: 'short', day: 'numeric' }));
        
        const mult = getSeasonalMultiplier(i);
        const expectedSales = velocity * mult;
        actualData.push(null);
        forecastData.push(Math.round(expectedSales));
        ropData.push(rop);
        safetyStockData.push(product.safetyStock);

        // Projected Stock (No action)
        noOrderStock = Math.max(0, noOrderStock - expectedSales);
        projectedStockData.push(Math.round(noOrderStock));

        // Simulated restock scenario (Order EOQ when stock <= ROP)
        if (orderStock <= rop && !orderPlaced) {
            orderPlaced = true;
            orderDeliveryDay = i + product.leadTime;
        }

        if (orderPlaced && i === orderDeliveryDay) {
            orderStock += eoq;
            orderPlaced = false;
        }
        orderStock = Math.max(0, orderStock - expectedSales);
        restockedStockData.push(Math.round(orderStock));
    }

    // Destroy previous chart
    if (forecastChartInstance) {
        forecastChartInstance.destroy();
    }

    forecastChartInstance = new Chart(ctxForecast.getContext('2d'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Historical Sales (Units)',
                    data: actualData,
                    borderColor: 'rgba(255, 255, 255, 0.4)',
                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                    fill: true,
                    tension: 0.3
                },
                {
                    label: 'AI Forecasted Demand',
                    data: forecastData,
                    borderColor: 'rgba(56, 189, 248, 1)',
                    borderDash: [5, 5],
                    backgroundColor: 'rgba(56, 189, 248, 0.1)',
                    fill: false,
                    tension: 0.3
                },
                {
                    label: 'Stock Depletion (No Restock)',
                    data: [...Array(historyDays).fill(null), product.stock, ...projectedStockData.slice(1)],
                    borderColor: 'rgba(244, 63, 94, 0.8)',
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    tension: 0.1
                },
                {
                    label: 'Restocked Stock Level',
                    data: [...Array(historyDays).fill(null), product.stock, ...restockedStockData.slice(1)],
                    borderColor: 'rgba(16, 185, 129, 0.8)',
                    backgroundColor: 'transparent',
                    borderWidth: 2.5,
                    tension: 0.1
                },
                {
                    label: 'Reorder Point (ROP)',
                    data: ropData,
                    borderColor: 'rgba(245, 158, 11, 0.5)',
                    borderWidth: 1.5,
                    borderDash: [2, 2],
                    pointStyle: 'none',
                    fill: false
                },
                {
                    label: 'Safety Stock Limit',
                    data: safetyStockData,
                    borderColor: 'rgba(244, 63, 94, 0.4)',
                    borderWidth: 1,
                    pointStyle: 'none',
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#9ca3af', font: { family: 'Inter' } }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.03)' },
                    ticks: { color: '#6b7280' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.03)' },
                    ticks: { color: '#6b7280' }
                }
            }
        }
    });

    // Doughnut chart
    const ctxHealth = document.getElementById('healthDoughnutChart');
    if (!ctxHealth) return;

    let healthyCount = 0;
    let lowCount = 0;
    let outCount = 0;

    state.products.forEach(p => {
        const status = getProductStatus(p).label;
        if (status === 'Healthy') healthyCount++;
        else if (status === 'Low Stock') lowCount++;
        else outCount++;
    });

    if (healthDoughnutChartInstance) {
        healthDoughnutChartInstance.destroy();
    }

    healthDoughnutChartInstance = new Chart(ctxHealth.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: ['Healthy', 'Low Stock', 'Out of Stock'],
            datasets: [{
                data: [healthyCount, lowCount, outCount],
                backgroundColor: [
                    '#10b981', // green
                    '#f59e0b', // orange
                    '#f43f5e'  // red
                ],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#9ca3af', font: { family: 'Inter' } }
                }
            }
        }
    });
}

function updateForecastDropdown() {
    const selector = document.getElementById('forecast-product-selector');
    if (!selector) return;

    const prevVal = selector.value;
    selector.innerHTML = '';
    
    state.products.forEach(p => {
        const option = document.createElement('option');
        option.value = p.id;
        option.textContent = p.name;
        selector.appendChild(option);
    });

    if (prevVal && state.products.some(p => p.id === prevVal)) {
        selector.value = prevVal;
    }
}

// Navigation Tabs Router
function switchTab(tabId) {
    state.currentTab = tabId;
    
    // update navigation styling
    document.querySelectorAll('.nav-item').forEach(btn => {
        if (btn.getAttribute('data-tab') === tabId) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    // switch panel visibility
    document.querySelectorAll('.tab-panel').forEach(panel => {
        if (panel.id === `tab-${tabId}`) {
            panel.classList.add('active');
        } else {
            panel.classList.remove('active');
        }
    });

    // Trigger tab specific renders
    if (tabId === 'dashboard') {
        renderDashboard();
        updateForecastDropdown();
        setupCharts();
    } else if (tabId === 'inventory') {
        renderInventory();
    } else if (tabId === 'optimizer') {
        renderOptimizer();
    } else if (tabId === 'orders') {
        renderOrders();
    }
}

// Event Bindings
function bindEvents() {
    // Nav tabs
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.addEventListener('click', () => {
            switchTab(btn.getAttribute('data-tab'));
        });
    });

    // Global Search
    document.getElementById('global-search').addEventListener('input', () => {
        if (state.currentTab === 'inventory') {
            inventoryPage = 1;
            renderInventory();
        }
    });

    // Inventory dropdown filters
    document.getElementById('inventory-filter-category').addEventListener('change', () => {
        inventoryPage = 1;
        renderInventory();
    });
    document.getElementById('inventory-filter-status').addEventListener('change', () => {
        inventoryPage = 1;
        renderInventory();
    });

    // Forecast selector dropdown
    document.getElementById('forecast-product-selector').addEventListener('change', () => {
        setupCharts();
    });

    // Modals control
    document.getElementById('btn-quick-add').addEventListener('click', () => {
        openModal();
    });
    document.getElementById('modal-close-btn').addEventListener('click', () => closeModal());
    document.getElementById('modal-cancel-btn').addEventListener('click', () => closeModal());
    
    // Save Product Form
    document.getElementById('product-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveProduct();
    });

    // Save Cost parameters settings
    document.getElementById('btn-save-cost-settings').addEventListener('click', () => {
        const orderCost = parseFloat(document.getElementById('setting-order-cost').value);
        const holdingCostRate = parseFloat(document.getElementById('setting-holding-cost-rate').value) / 100;
        
        if (orderCost >= 0 && holdingCostRate >= 0.01) {
            state.settings.orderCost = orderCost;
            state.settings.holdingRate = holdingCostRate;
            saveState();
            addNotification('AI Cost Parameters updated successfully!', 'success');
            playBeep('success');
            renderAll();
        }
    });

    // Gemini API Connection settings
    document.getElementById('btn-test-gemini').addEventListener('click', async () => {
        const key = document.getElementById('setting-gemini-key').value;
        const model = document.getElementById('setting-model-select').value;
        const statusEl = document.getElementById('gemini-test-status');
        
        statusEl.textContent = 'Connecting...';
        statusEl.style.color = 'var(--text-muted)';
        
        if (!key) {
            statusEl.textContent = 'Key required';
            statusEl.style.color = 'var(--danger)';
            return;
        }

        try {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: 'Respond with the word "Success" and nothing else.' }] }]
                })
            });
            const data = await response.json();
            if (data.candidates && data.candidates[0].content.parts[0].text) {
                statusEl.textContent = 'Connected Successfully!';
                statusEl.style.color = 'var(--success)';
                state.settings.geminiKey = key;
                state.settings.geminiModel = model;
                saveState();
                playBeep('success');
            } else {
                throw new Error('Invalid response');
            }
        } catch (e) {
            statusEl.textContent = 'Connection Failed';
            statusEl.style.color = 'var(--danger)';
        }
    });

    // Sales simulator slider text sync
    document.getElementById('setting-demand-volatility').addEventListener('input', (e) => {
        const val = e.target.value;
        document.getElementById('range-volatility-val').textContent = `${val}%`;
        state.settings.volatility = parseFloat(val) / 100;
        saveState();
    });
    
    document.getElementById('setting-seasonality').addEventListener('input', (e) => {
        const val = e.target.value;
        document.getElementById('range-seasonality-val').textContent = `${val}%`;
        state.settings.seasonality = parseFloat(val) / 100;
        saveState();
    });

    // Simulate 1 Day
    document.getElementById('btn-sim-day').addEventListener('click', () => {
        simulateSales(1);
        addNotification('Simulated 1 day of consumer sales.', 'info');
    });

    // Simulate 1 Week
    document.getElementById('btn-sim-week').addEventListener('click', () => {
        simulateSales(7);
        addNotification('Simulated 7 days of consumer sales.', 'info');
    });

    // Reset Simulator
    document.getElementById('btn-reset-simulator').addEventListener('click', () => {
        if (confirm('Reset catalog and orders to default values? All customized inventory records will be lost.')) {
            localStorage.clear();
            state.products = [...DEFAULT_PRODUCTS];
            state.orders = [...DEFAULT_ORDERS];
            state.notifications = [];
            state.simulatedDays = 0;
            state.settings = {
                orderCost: 500,
                holdingRate: 0.20,
                geminiKey: '',
                geminiModel: 'gemini-1.5-flash',
                volatility: 0.15,
                seasonality: 0.25
            };
            saveState();
            loadState();
            addNotification('Workspace reset to initial state.', 'info');
            playBeep('success');
            renderAll();
            switchTab('dashboard');
        }
    });

    // Notification drop-down toggle
    const bell = document.getElementById('bell-icon');
    const dropdown = document.getElementById('notification-dropdown');
    bell.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('active');
        // Mark all as read
        state.notifications.forEach(n => n.read = true);
        saveState();
        updateNotificationBadge();
    });

    document.addEventListener('click', () => {
        dropdown.classList.remove('active');
    });

    document.getElementById('clear-notifications').addEventListener('click', (e) => {
        e.stopPropagation();
        state.notifications = [];
        saveState();
        renderNotifications();
        updateNotificationBadge();
    });

    // Bulk restocking approve
    document.getElementById('btn-approve-selected').addEventListener('click', () => {
        approveSelectedRestocks();
    });

    // Bulk selection checkbox
    document.getElementById('select-all-recommendations').addEventListener('change', (e) => {
        const checked = e.target.checked;
        document.querySelectorAll('.opt-select').forEach(box => {
            box.checked = checked;
        });
        updateSelectedRestockCount();
    });

    // Export CSV
    document.getElementById('btn-export-csv').addEventListener('click', () => {
        exportInventoryToCSV();
    });
}

// Bulk Order approval
function approveSelectedRestocks() {
    const checkboxes = document.querySelectorAll('.opt-select:checked');
    if (checkboxes.length === 0) return;

    const newOrderItems = [];
    let totalCost = 0;

    checkboxes.forEach(box => {
        const id = box.getAttribute('data-id');
        const prod = state.products.find(p => p.id === id);
        if (prod) {
            const qty = calculateEOQ(prod);
            newOrderItems.push({
                name: prod.name,
                qty: qty,
                cost: prod.cost
            });
            totalCost += qty * prod.cost;
        }
    });

    const newOrder = {
        id: 'ord-' + Math.floor(1000 + Math.random() * 9000),
        dateCreated: new Date().toISOString().split('T')[0],
        items: newOrderItems,
        totalCost: totalCost,
        expectedDelivery: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 5 days from now
        status: 'In Transit'
    };

    state.orders.unshift(newOrder);
    addNotification(`New Purchase Order ${newOrder.id} generated for ${newOrderItems.length} products. Total cost: ${formatRupees(totalCost)}.`, 'success');
    playBeep('success');

    saveState();
    renderAll();
    switchTab('orders');
}

// CSV exporter
function exportInventoryToCSV() {
    let csv = 'SKU,Product Name,Category,Current Stock,Unit Price (INR),Unit Cost (INR),Supplier Lead Time (Days),Safety Stock\n';
    
    state.products.forEach(p => {
        csv += `"${p.sku}","${p.name.replace(/"/g, '""')}","${p.category}",${p.stock},${p.price},${p.cost},${p.leadTime},${p.safetyStock}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'aurastock_inventory_report.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// CRUD - Product Modals
function openModal(prodId = null) {
    const overlay = document.getElementById('product-modal');
    const title = document.getElementById('modal-title');
    const submitBtn = document.getElementById('modal-submit-btn');
    const form = document.getElementById('product-form');

    form.reset();
    document.getElementById('form-product-id').value = '';

    if (prodId) {
        title.textContent = 'Edit Product Details';
        submitBtn.textContent = 'Update Product';
        const p = state.products.find(item => item.id === prodId);
        if (p) {
            document.getElementById('form-product-id').value = p.id;
            document.getElementById('form-name').value = p.name;
            document.getElementById('form-category').value = p.category;
            document.getElementById('form-stock').value = p.stock;
            document.getElementById('form-price').value = p.price;
            document.getElementById('form-cost').value = p.cost;
            document.getElementById('form-lead-time').value = p.leadTime;
            document.getElementById('form-safety-stock').value = p.safetyStock;
            document.getElementById('form-annual-demand').value = p.annualDemand;
        }
    } else {
        title.textContent = 'Add New Product';
        submitBtn.textContent = 'Save Product';
    }

    overlay.classList.add('active');
}

function closeModal() {
    document.getElementById('product-modal').classList.remove('active');
}

function saveProduct() {
    const id = document.getElementById('form-product-id').value;
    const name = document.getElementById('form-name').value;
    const category = document.getElementById('form-category').value;
    const stock = parseInt(document.getElementById('form-stock').value);
    const price = parseFloat(document.getElementById('form-price').value);
    const cost = parseFloat(document.getElementById('form-cost').value);
    const leadTime = parseInt(document.getElementById('form-lead-time').value);
    const safetyStock = parseInt(document.getElementById('form-safety-stock').value);
    const annualDemand = parseInt(document.getElementById('form-annual-demand').value);

    if (id) {
        // Edit Mode
        const p = state.products.find(item => item.id === id);
        if (p) {
            p.name = name;
            p.category = category;
            p.stock = stock;
            p.price = price;
            p.cost = cost;
            p.leadTime = leadTime;
            p.safetyStock = safetyStock;
            p.annualDemand = annualDemand;
            p.dailyVelocity = annualDemand / 365;
            addNotification(`Product "${name}" updated successfully.`, 'success');
        }
    } else {
        // Add Mode
        const randomSku = `${category.slice(0,3).toUpperCase()}-${name.slice(0,4).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`;
        const newP = {
            id: 'prod-' + Math.random().toString(36).substr(2, 9),
            sku: randomSku,
            name,
            category,
            stock,
            price,
            cost,
            leadTime,
            safetyStock,
            annualDemand,
            dailyVelocity: annualDemand / 365
        };
        state.products.push(newP);
        addNotification(`New Product "${name}" added with SKU ${randomSku}.`, 'success');
    }

    playBeep('success');
    saveState();
    closeModal();
    renderAll();
}

function editProduct(prodId) {
    openModal(prodId);
}

function deleteProduct(prodId) {
    const p = state.products.find(item => item.id === prodId);
    if (!p) return;

    if (confirm(`Are you sure you want to delete "${p.name}"? This action cannot be undone.`)) {
        state.products = state.products.filter(item => item.id !== prodId);
        addNotification(`Deleted product "${p.name}".`, 'warning');
        playBeep('alert');
        saveState();
        renderAll();
    }
}

// Notifications Rendering
function renderNotifications() {
    const list = document.getElementById('notification-list');
    list.innerHTML = '';

    if (state.notifications.length === 0) {
        list.innerHTML = `<div style="padding:20px; text-align:center; color:var(--text-muted); font-size:0.85rem">No notifications.</div>`;
        return;
    }

    state.notifications.forEach(n => {
        const item = document.createElement('div');
        item.className = `dropdown-item ${n.read ? '' : 'unread'}`;
        
        let typeColor = 'var(--accent)';
        if (n.type === 'warning') typeColor = 'var(--warning)';
        if (n.type === 'danger') typeColor = 'var(--danger)';
        if (n.type === 'success') typeColor = 'var(--success)';

        item.innerHTML = `
            <div style="display:flex; gap:8px;">
                <div style="width:6px; height:6px; border-radius:50%; background-color:${typeColor}; margin-top:6px; flex-shrink:0;"></div>
                <div>
                    <div>${n.message}</div>
                    <span class="dropdown-item-time">${n.timestamp}</span>
                </div>
            </div>
        `;
        list.appendChild(item);
    });
}

function updateNotificationBadge() {
    const unreadCount = state.notifications.filter(n => !n.read).length;
    const badge = document.getElementById('notification-badge');
    const navBadge = document.getElementById('nav-alert-count');
    
    // Update bell badge
    if (unreadCount > 0) {
        badge.style.display = 'block';
    } else {
        badge.style.display = 'none';
    }

    // Update Nav bar optimizer badge (low stock items)
    const lowStockCount = state.products.filter(p => p.stock <= calculateROP(p)).length;
    if (lowStockCount > 0) {
        navBadge.style.display = 'block';
        navBadge.textContent = lowStockCount;
    } else {
        navBadge.style.display = 'none';
    }
}

// Global Render Coordinator
function renderAll() {
    renderNotifications();
    updateNotificationBadge();

    if (state.currentTab === 'dashboard') {
        renderDashboard();
        updateForecastDropdown();
        setupCharts();
    } else if (state.currentTab === 'inventory') {
        renderInventory();
    } else if (state.currentTab === 'optimizer') {
        renderOptimizer();
    } else if (state.currentTab === 'orders') {
        renderOrders();
    }
}

// Page load initialization
window.addEventListener('DOMContentLoaded', () => {
    loadState();
    bindEvents();
    renderAll();
    
    // Small delay to ensure charts are layout ready
    setTimeout(() => {
        setupCharts();
    }, 200);
});
