# FreshStock AI

A static grocery restocking and profit optimization dashboard.

## Features

- Demand forecasting from weekly sales, sales trend, and seasonal lift
- Restock recommendations using supplier lead time, MOQ, budget, and storage constraints
- Overstock, expiry, and stockout risk detection
- Profit opportunity ranking
- CSV import/export
- Manual product entry
- Text report export
- Vercel-ready static deployment

## Files

- `outputs/index.html` - the complete website
- `vercel.json` - Vercel static deployment configuration
- `.vercelignore` - excludes local working files from deployment

## Run Locally

Open `outputs/index.html` in a browser.

## Deploy To Vercel

```powershell
npx vercel@latest --prod
```

Vercel will publish the `outputs` directory.
